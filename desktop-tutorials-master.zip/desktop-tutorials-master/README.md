# desktop-tutorials
all python projects
python project practical on github
